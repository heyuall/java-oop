package tp3;

public class Dictionnaire extends Volume {

    public Dictionnaire(String t, String a) {
        super(t, a);
    }
}