package tp3;

public class Etudiant extends Adherant {

    public Etudiant(String nom, String CIN) {
        super(nom, CIN);
    }

}
