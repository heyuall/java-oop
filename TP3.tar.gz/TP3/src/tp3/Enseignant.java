package tp3;

public class Enseignant extends Adherant {

    public Enseignant(String nom, String CIN) {
        super(nom, CIN);
    }

}
